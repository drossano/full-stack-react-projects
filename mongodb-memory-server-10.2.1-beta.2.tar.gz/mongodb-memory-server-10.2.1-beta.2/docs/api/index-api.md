---
id: index-api
title: 'Welcome to the API'
---

In `API` will be documented what functions & values do, even internal `protected` / `private` ones

## Interfaces & Options

To get the options, the tsdoc (source) should be used directly ([FAQ](../guides/faq.md#why-is-there-no-documentation-about-class-options--interfaces-in-the-documentation))
