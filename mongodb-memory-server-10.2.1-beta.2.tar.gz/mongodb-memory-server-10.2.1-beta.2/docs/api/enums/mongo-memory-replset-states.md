---
id: mongo-memory-replset-states
title: 'MongoMemoryReplSetStates'
---

API Documentation of `MongoMemoryReplSetStates`-Enum

## Members

### init

Value: `init`

Indicates that the instance is currently starting.

### running

Value: `running`

Indicates that the instance is currently running.

### stopped

Value: `stopped`

Indicates that the instance is currently stopped.
