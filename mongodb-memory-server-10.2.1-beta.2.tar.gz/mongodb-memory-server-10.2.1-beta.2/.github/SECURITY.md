# Security Policy

## Supported Versions

|  Version  | Supported          |
| --------- | ------------------ |
|   latest  | :white_check_mark: |
| < latest  | :x:                |

## Reporting a Vulnerability

Because this is an open-source Project, please report it like any other issue.
