---
name: Question
about: Ask a question
title: ''
labels: question
assignees: ''
---

<!--
Make sure you read [Mastering-Markdown](https://guides.github.com/features/mastering-markdown/)
-->

## Versions

- NodeJS: 0.0.0
- mongodb-memory-server-*: 0.0.0 <!--"latest" is not a version-->
- mongodb(the binary version): 0.0.0
- mongodb(the js package): 0.0.0
- mongoose: 0.0.0 <!--remove this if not used-->
- system: <!--either Windows, MacOS, Linux (with distro and distro version)-->

package: mongo-memory-server <!--State the package you are using-->
<!--
possible are:
mongo-memory-server
mongo-memory-server-core
mongo-memory-server-global
-->

## What is your question?

<!--Please include code samples if the question is about it-->
