---
name: Documentation
about: Use this if the issue is about Documentation
title: ''
labels: docs
assignees: ''
---

<!--
## What to include in your Issue

- Make sure you read [Mastering-Markdown](https://guides.github.com/features/mastering-markdown/)

- If it is about missing documentation, please add which feature (when possible add an code link)
- If it is about somthing different, please provide all information that could be useful
-->
