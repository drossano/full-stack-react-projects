# mongodb-memory-server-global-4.2

[![Node.js CI](https://github.com/typegoose/mongodb-memory-server/workflows/Node.js%20CI/badge.svg)](https://github.com/typegoose/mongodb-memory-server/actions/workflows/tests.yml?query=workflow%3A%22Node.js+CI%22)
[![NPM version](https://img.shields.io/npm/v/mongodb-memory-server-global-4.2.svg)](https://www.npmjs.com/package/mongodb-memory-server-global-4.2)
[![Downloads stat](https://img.shields.io/npm/dt/mongodb-memory-server-global-4.2.svg)](http://www.npmtrends.com/mongodb-memory-server-global-4.2)
[![Commitizen friendly](https://img.shields.io/badge/commitizen-friendly-brightgreen.svg)](http://commitizen.github.io/cz-cli/)
[![TypeScript compatible](https://img.shields.io/badge/typescript-compatible-brightgreen.svg)](https://www.typescriptlang.org)
[![codecov.io](https://codecov.io/github/typegoose/mongodb-memory-server/coverage.svg?branch=master)](https://codecov.io/github/typegoose/mongodb-memory-server?branch=master)
[![Backers on Open Collective](https://opencollective.com/mongodb-memory-server/backers/badge.svg)](#backers)
[![Sponsors on Open Collective](https://opencollective.com/mongodb-memory-server/sponsors/badge.svg)](#sponsors)
[![mongodb-memory-server-global-4.2](https://snyk.io/advisor/npm-package/mongodb-memory-server-global-4.2/badge.svg)](https://snyk.io/advisor/npm-package/mongodb-memory-server-global-4.2)

Main default package which downloads `v4.2` mongod binary to `%HOME/.cache/mongodb-binaries` directory on package install.

[Full README with avaliable options and examples](https://github.com/typegoose/mongodb-memory-server)
