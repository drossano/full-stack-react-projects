# Packages

**The main package with source code is [mongodb-memory-server-core](./mongodb-memory-server-core).**

All other packages just include `postinstall` script which downloads mongod binary on npm install with provided default configuration.
