/* eslint-disable @typescript-eslint/no-var-requires */
'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
const tslib = require('tslib');
tslib.__exportStar(require('mongodb-memory-server-core'), exports);
