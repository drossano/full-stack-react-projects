Note that the certificates in this folder are only for the test servers.
