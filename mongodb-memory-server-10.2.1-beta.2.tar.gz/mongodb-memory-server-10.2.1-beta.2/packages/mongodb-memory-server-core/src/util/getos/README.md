The package `getos` didnt got updates in a long time and important Pull Requests werent merged, so it got copied here and tweaked to the needs of `mongodb-memory-server`
