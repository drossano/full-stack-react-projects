This sub-module is inspired by `get-port`, which started shipping ESM-only builds and we werent able to upgrade yet, also to address memory leaks (not using intervals or timeouts)
